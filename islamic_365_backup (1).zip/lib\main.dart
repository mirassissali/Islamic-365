import 'package:flutter/material.dart';
import 'core/theme_manager.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const Islamic365App());
}

class Islamic365App extends StatelessWidget {
  const Islamic365App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Islamic 365',
      debugShowCheckedModeBanner: false,
      theme: ThemeManager.theme,
      home: const HomeScreen(),
    );
  }
}
