import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../../models/daily_essential.dart';
import '../../core/theme_manager.dart';

class InfiniteMarqueeSection extends StatefulWidget {
  final List<DailyEssential> essentials;
  const InfiniteMarqueeSection({super.key, required this.essentials});

  @override
  State<InfiniteMarqueeSection> createState() => _InfiniteMarqueeSectionState();
}

class _InfiniteMarqueeSectionState extends State<InfiniteMarqueeSection> {
  bool _isPaused = false;

  @override
  Widget build(BuildContext context) {
    // Split 24 items (assuming 23+ were provided) into two rows
    final int half = (widget.essentials.length / 2).ceil();
    final row1Items = widget.essentials.take(half).toList();
    final row2Items = widget.essentials.skip(half).toList();

    return Column(
      children: [
        _MarqueeRow(
          items: row1Items,
          reverse: false,
          isPaused: _isPaused,
          onInteraction: _togglePause,
        ),
        const SizedBox(height: 16),
        _MarqueeRow(
          items: row2Items,
          reverse: true,
          isPaused: _isPaused,
          onInteraction: _togglePause,
        ),
        if (_isPaused)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Text(
              "Tap anywhere to resume",
              style: TextStyle(
                color: ThemeManager.goldAccent,
                fontSize: 10,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
          ),
      ],
    );
  }

  void _togglePause() {
    setState(() {
      _isPaused = !_isPaused;
    });
  }
}

class _MarqueeRow extends StatefulWidget {
  final List<DailyEssential> items;
  final bool reverse;
  final bool isPaused;
  final VoidCallback onInteraction;

  const _MarqueeRow({
    required this.items,
    required this.reverse,
    required this.isPaused,
    required this.onInteraction,
  });

  @override
  State<_MarqueeRow> createState() => _MarqueeRowState();
}

class _MarqueeRowState extends State<_MarqueeRow> with SingleTickerProviderStateMixin {
  late ScrollController _scrollController;
  late AnimationController _animationController;
  final double _speed = 35.0; // Slightly slower for readability

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    )..repeat();
    _animationController.addListener(_scrollListener);
    
    // Initial jump to middle for reverse
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.jumpTo(_scrollController.position.maxScrollExtent / 2);
      }
    });
  }

  void _scrollListener() {
    if (!widget.isPaused && _scrollController.hasClients) {
      double maxScroll = _scrollController.position.maxScrollExtent;
      double currentScroll = _scrollController.offset;
      double delta = _speed / 60.0;

      if (widget.reverse) {
        if (currentScroll <= 0) {
          _scrollController.jumpTo(maxScroll / 2);
        } else {
          _scrollController.jumpTo(currentScroll - delta);
        }
      } else {
        if (currentScroll >= maxScroll) {
          _scrollController.jumpTo(maxScroll / 2);
        } else {
          _scrollController.jumpTo(currentScroll + delta);
        }
      }
    }
  }

  @override
  void dispose() {
    _animationController.removeListener(_scrollListener);
    _animationController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Quadruple items to ensure no gaps
    final quadItems = [...widget.items, ...widget.items, ...widget.items, ...widget.items];

    return SizedBox(
      height: 95,
      child: ListView.builder(
        controller: _scrollController,
        scrollDirection: Axis.horizontal,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: quadItems.length,
        itemBuilder: (context, index) {
          final item = quadItems[index];
          return GestureDetector(
            onTap: widget.onInteraction,
            onLongPress: widget.onInteraction,
            child: AnimatedScale(
              scale: widget.isPaused ? 1.05 : 1.0,
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeOutBack,
              child: _MarqueeItem(item: item, isPaused: widget.isPaused),
            ),
          );
        },
      ),
    );
  }
}

class _MarqueeItem extends StatelessWidget {
  final DailyEssential item;
  final bool isPaused;
  const _MarqueeItem({required this.item, required this.isPaused});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 85,
      margin: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: isPaused ? ThemeManager.goldAccent.withValues(alpha: 0.3) : Colors.transparent,
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: (isPaused ? ThemeManager.goldAccent : Colors.black).withValues(alpha: 0.08),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: isPaused ? ThemeManager.goldAccent.withValues(alpha: 0.1) : ThemeManager.mintGreen.withValues(alpha: 0.5),
              shape: BoxShape.circle,
            ),
            child: FaIcon(
              item.icon,
              size: 20,
              color: isPaused ? ThemeManager.goldAccent : Theme.of(context).primaryColor,
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Text(
              item.label,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w800,
                color: isPaused ? ThemeManager.goldAccent : Theme.of(context).primaryColor,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}

