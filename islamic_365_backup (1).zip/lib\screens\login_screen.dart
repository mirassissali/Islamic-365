import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../core/theme_manager.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeManager.backgroundCream,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.close_rounded, color: ThemeManager.darkGreen),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),
            Text(
              'Welcome to\nIslamic 365',
              style: Theme.of(context).textTheme.displaySmall?.copyWith(
                color: ThemeManager.darkGreen,
                fontWeight: FontWeight.bold,
                height: 1.2,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Join the global community of believers and access premium features.',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: ThemeManager.darkGreen.withValues(alpha: 0.7),
              ),
            ),
            const SizedBox(height: 60),
            _buildSocialButton(
              context,
              icon: FontAwesomeIcons.google,
              label: 'Continue with Google',
              color: Colors.white,
              textColor: ThemeManager.darkGreen,
            ),
            const SizedBox(height: 16),
            _buildSocialButton(
              context,
              icon: FontAwesomeIcons.apple,
              label: 'Continue with Apple',
              color: Colors.black,
              textColor: Colors.white,
            ),
            const SizedBox(height: 16),
            _buildSocialButton(
              context,
              icon: Icons.email_rounded,
              label: 'Continue with Email',
              color: ThemeManager.darkGreen,
              textColor: Colors.white,
            ),
            const Spacer(),
            Center(
              child: TextButton(
                onPressed: () {},
                child: Text(
                  'Don\'t have an account? Sign Up',
                  style: TextStyle(
                    color: ThemeManager.goldAccent,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildSocialButton(
    BuildContext context, {
    required dynamic icon,
    required String label,
    required Color color,
    required Color textColor,
  }) {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: ElevatedButton(
        onPressed: () {
          // Mock login success
          Navigator.pop(context, true);
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: textColor,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: color == Colors.white 
                ? BorderSide(color: ThemeManager.darkGreen.withValues(alpha: 0.1))
                : BorderSide.none,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon is IconData) Icon(icon, size: 20) else FaIcon(icon as FaIconData, size: 20),
            const SizedBox(width: 12),
            Text(
              label,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }
}
