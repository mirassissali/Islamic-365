import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../core/theme_manager.dart';

class SpiritualJourneyCard extends StatelessWidget {
  const SpiritualJourneyCard({super.key});

  @override
  Widget build(BuildContext context) {
    const double currentXp = 750;
    const double nextXp = 1000;
    const double progress = currentXp / nextXp;

    final List<Map<String, dynamic>> chests = [
      {'label': 'BRONZE', 'unlocked': true, 'color': const Color(0xFFCD7F32)},
      {'label': 'COPPER', 'unlocked': false, 'color': Colors.grey},
      {'label': 'SILVER', 'unlocked': false, 'color': Colors.grey},
      {'label': 'GOLD', 'unlocked': false, 'color': Colors.grey},
    ];

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Spiritual Journey',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontSize: 20,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: ThemeManager.lightYellow,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '${currentXp.toInt()} XP',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: ThemeManager.goldAccent,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          // Chest icons
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: chests.map((chest) {
              final bool unlocked = chest['unlocked'] as bool;
              final Color color = chest['color'] as Color;
              return Column(
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          color: unlocked
                              ? ThemeManager.lightYellow
                              : ThemeManager.backgroundCream,
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      FaIcon(
                        unlocked
                            ? FontAwesomeIcons.boxOpen
                            : FontAwesomeIcons.lock,
                        size: 22,
                        color: color,
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    chest['label'] as String,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.1,
                      color: unlocked
                          ? Theme.of(context).primaryColor
                          : Colors.grey[400],
                    ),
                  ),
                ],
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          // Progress bar
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: SizedBox(
              height: 8,
              child: LinearProgressIndicator(
                value: progress,
                backgroundColor: ThemeManager.backgroundCream,
                valueColor: AlwaysStoppedAnimation<Color>(
                  Theme.of(context).primaryColor,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: Text(
              '${(nextXp - currentXp).toInt()} XP UNTIL COPPER CHEST',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontSize: 10,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.2,
                color: Colors.grey[500],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
