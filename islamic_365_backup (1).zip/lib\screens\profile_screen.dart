import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../core/theme_manager.dart';
import 'login_screen.dart';

// Essential Pages
import '../pages/essentials/community.dart';
import '../pages/essentials/daily_streak.dart';
import '../pages/essentials/donation.dart';
import '../pages/essentials/dua_bank.dart';
import '../pages/essentials/events.dart';
import '../pages/essentials/hadith.dart';
import '../pages/essentials/hajj_guide.dart';
import '../pages/essentials/halal_find.dart';
import '../pages/essentials/hijri_date.dart';
import '../pages/essentials/islamic_quiz.dart';
import '../pages/essentials/knowledge_share.dart';
import '../pages/essentials/leaderboard.dart';
import '../pages/essentials/masjid_finder.dart';
import '../pages/essentials/names_99.dart';
import '../pages/essentials/qibla.dart';
import '../pages/essentials/quran_audio.dart';
import '../pages/essentials/quran_read.dart';
import '../pages/essentials/refer_earn.dart';
import '../pages/essentials/sadqah.dart';
import '../pages/essentials/store.dart';
import '../pages/essentials/tafsir_hub.dart';
import '../pages/essentials/tasbeeh.dart';
import '../pages/essentials/wallet.dart';
import '../pages/essentials/zakat_calculator.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _isLoggedIn = false;

  void _handleLogin() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const LoginScreen()),
    );
    if (result == true) {
      setState(() {
        _isLoggedIn = true;
      });
    }
  }

  void _handleLogout() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                _isLoggedIn = false;
              });
              Navigator.pop(context);
            },
            child: const Text('Logout', style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      backgroundColor: ThemeManager.backgroundCream,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(context, textTheme),
              _buildMembershipCard(context),
              _buildHorizontalActionBar(context),
              _buildSettingsSection(context, textTheme),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context, TextTheme textTheme) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _isLoggedIn ? 'Assalamu Alaikum,' : 'As Salamu Alekum',
                style: textTheme.titleLarge?.copyWith(
                  color: ThemeManager.darkGreen,
                  fontSize: 24,
                ),
              ),
              const SizedBox(height: 4),
              GestureDetector(
                onTap: _isLoggedIn ? null : _handleLogin,
                child: Text(
                  _isLoggedIn ? 'Adyan Syah' : 'Tap to Login',
                  style: textTheme.bodyMedium?.copyWith(
                    color: ThemeManager.goldAccent,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          CircleAvatar(
            radius: 30,
            backgroundColor: ThemeManager.mintGreen,
            backgroundImage: _isLoggedIn 
                ? const NetworkImage('https://i.pravatar.cc/150?u=adyan')
                : null,
            child: !_isLoggedIn ? const Icon(
              Icons.person_outline,
              size: 35,
              color: ThemeManager.darkGreen,
            ) : null,
          ),
        ],
      ),
    );
  }

  Widget _buildMembershipCard(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [ThemeManager.darkGreen, ThemeManager.darkGreenAccent],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: ThemeManager.darkGreen.withValues(alpha: 0.3),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const FaIcon(FontAwesomeIcons.crown, color: ThemeManager.goldAccent, size: 16),
                  const SizedBox(width: 8),
                  Text(
                    'Membership',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                'Unlock Premium Features',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Colors.white70,
                ),
              ),
            ],
          ),
          ElevatedButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const StorePage())),
            style: ElevatedButton.styleFrom(
              backgroundColor: ThemeManager.goldAccent,
              foregroundColor: ThemeManager.darkGreen,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            ),
            child: const Text('Claim', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Widget _buildHorizontalActionBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildActionItem(context, FontAwesomeIcons.gamepad, 'Game', const IslamicQuizPage()),
          _buildActionItem(context, FontAwesomeIcons.chartLine, 'Level', const LeaderboardPage()),
          _buildActionItem(context, FontAwesomeIcons.wallet, 'Wallet', const WalletPage()),
          _buildActionItem(context, FontAwesomeIcons.handHoldingHeart, 'Donate', const DonationPage()),
          _buildActionItem(context, FontAwesomeIcons.shop, 'Store', const StorePage()),
        ],
      ),
    );
  }

  Widget _buildActionItem(BuildContext context, dynamic icon, String label, Widget destination) {
    return InkWell(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => destination)),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: ThemeManager.mintGreen,
              shape: BoxShape.circle,
            ),
            child: FaIcon(icon, color: ThemeManager.darkGreen, size: 20),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: ThemeManager.darkGreen,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsSection(BuildContext context, TextTheme textTheme) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle(context, 'Core Settings'),
          _buildSettingTile(context, Icons.settings_outlined, 'Main Settings'),
          _buildSettingTile(context, Icons.notifications_none_outlined, 'Notifications'),
          _buildSettingTile(context, Icons.volume_up_outlined, 'Audio Settings', destination: const QuranAudioPage()),
          _buildSettingTile(context, Icons.menu_book_outlined, 'Reading Settings', destination: const QuranReadPage()),
          
          const SizedBox(height: 20),
          _buildSectionTitle(context, 'App Features'),
          _buildSettingTile(context, Icons.explore_outlined, 'Qibla Finder', destination: const QiblaPage()),
          _buildSettingTile(context, Icons.fingerprint, 'Tasbih Counter', destination: const TasbeehPage()),
          _buildSettingTile(context, Icons.mosque_outlined, 'Nearby Masjid', destination: const MasjidFinderPage()),
          _buildSettingTile(context, Icons.calendar_month_outlined, 'Islamic Calendar', destination: const HijriDatePage()),
          _buildSettingTile(context, Icons.favorite_outline, 'Zakat Calculator', destination: const ZakatCalculatorPage()),
          _buildSettingTile(context, Icons.auto_stories_outlined, 'Daily Adhkar', destination: const DuaBankPage()),
          _buildSettingTile(context, Icons.people_outline, 'Ummah Community', destination: const CommunityPage()),
          _buildSettingTile(context, Icons.live_tv_outlined, 'Makkah Live'),
          _buildSettingTile(context, Icons.star_outline, '99 Names of Allah', destination: const Names99Page()),
          _buildSettingTile(context, Icons.format_quote_outlined, 'Daily Hadith', destination: const HadithPage()),
          _buildSettingTile(context, Icons.map_outlined, 'Hajj & Umrah Guide', destination: const HajjGuidePage()),
          _buildSettingTile(context, Icons.restaurant_menu_rounded, 'Halal Finder', destination: const HalalFindPage()),
          _buildSettingTile(context, Icons.menu_book_rounded, 'Tafsir Hub', destination: const TafsirHubPage()),
          _buildSettingTile(context, Icons.volunteer_activism_rounded, 'Sadaqah', destination: const SadqahPage()),
          _buildSettingTile(context, Icons.lightbulb_rounded, 'Knowledge Share', destination: const KnowledgeSharePage()),
          _buildSettingTile(context, Icons.event_rounded, 'Islamic Events', destination: const EventsPage()),
          _buildSettingTile(context, Icons.flash_on_rounded, 'Daily Streak', destination: const DailyStreakPage()),
          _buildSettingTile(context, Icons.help_outline, 'Q&A Section'),
          _buildSettingTile(context, Icons.share_outlined, 'Invite Friends', destination: const ReferEarnPage()),
          _buildSettingTile(context, Icons.rate_review_outlined, 'Rate App'),
          _buildSettingTile(context, Icons.info_outline, 'About Us'),
          _buildSettingTile(context, Icons.privacy_tip_outlined, 'Privacy Policy'),
          _buildSettingTile(context, Icons.contact_support_outlined, 'Contact Support'),
          _buildSettingTile(context, Icons.logout_outlined, 'Logout', isDestructive: true, onTap: _handleLogout),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 10, bottom: 8),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleSmall?.copyWith(
          color: ThemeManager.goldAccent,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.2,
        ),
      ),
    );
  }

  Widget _buildSettingTile(BuildContext context, IconData icon, String title, {bool isDestructive = false, Widget? destination, VoidCallback? onTap}) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: isDestructive ? Colors.red.withValues(alpha: 0.1) : ThemeManager.mintGreen.withValues(alpha: 0.5),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(
          icon,
          color: isDestructive ? Colors.redAccent : ThemeManager.darkGreen,
          size: 20,
        ),
      ),
      title: Text(
        title,
        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
          color: isDestructive ? Colors.redAccent : ThemeManager.darkGreen,
          fontWeight: FontWeight.w500,
        ),
      ),
      trailing: Icon(
        Icons.chevron_right,
        color: isDestructive ? Colors.redAccent.withValues(alpha: 0.5) : ThemeManager.darkGreen.withValues(alpha: 0.3),
      ),
      onTap: onTap ?? () {
        if (destination != null) {
          Navigator.push(context, MaterialPageRoute(builder: (context) => destination));
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('$title functionality coming soon!')),
          );
        }
      },
    );
  }
}

