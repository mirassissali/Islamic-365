import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../../core/theme_manager.dart';

class DailyStreakPage extends StatefulWidget {
  const DailyStreakPage({super.key});

  @override
  State<DailyStreakPage> createState() => _DailyStreakPageState();
}

class _DailyStreakPageState extends State<DailyStreakPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Daily Streak', style: Theme.of(context).textTheme.titleLarge?.copyWith(
          color: AppColors.primary,
          fontWeight: FontWeight.bold,
        )),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.primary),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(30),
        child: Column(
          children: [
            _buildStreakCard(),
            const SizedBox(height: 40),
            _buildWeeklyCalendar(),
            const SizedBox(height: 40),
            _buildMilestones(),
          ],
        ),
      ),
    );
  }

  Widget _buildStreakCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(40),
      decoration: BoxDecoration(
        color: AppColors.primary,
        borderRadius: BorderRadius.circular(40),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withValues(alpha: 0.3),
            blurRadius: 25,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          const FaIcon(FontAwesomeIcons.fireFlameCurved, color: Colors.orange, size: 80),
          const SizedBox(height: 24),
          Text(
            '12 DAYS',
            style: Theme.of(context).textTheme.displayMedium?.copyWith(
              color: Colors.white,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Current Streak',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.white70),
          ),
        ],
      ),
    );
  }

  Widget _buildWeeklyCalendar() {
    final days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: List.generate(7, (index) {
        bool isDone = index < 4; // Mock data
        return Column(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: isDone ? AppColors.secondary : Colors.white,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.primary.withValues(alpha: 0.05)),
              ),
              child: isDone ? const Icon(Icons.check_rounded, color: Colors.white, size: 20) : null,
            ),
            const SizedBox(height: 8),
            Text(days[index], style: AppTextTheme.caption(context)),
          ],
        );
      }),
    );
  }

  Widget _buildMilestones() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Streak Milestones',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),
        _buildMilestoneItem('7 Days', 'Unlock Bronze Badge', true),
        _buildMilestoneItem('15 Days', 'Unlock Silver Badge', false),
        _buildMilestoneItem('30 Days', 'Unlock Gold Badge', false),
      ],
    );
  }

  Widget _buildMilestoneItem(String title, String sub, bool isUnlocked) {
    return Opacity(
      opacity: isUnlocked ? 1.0 : 0.5,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
        ),
        child: Row(
          children: [
            Icon(isUnlocked ? Icons.lock_open_rounded : Icons.lock_rounded, color: AppColors.secondary),
            const SizedBox(width: 20),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text(sub, style: const TextStyle(fontSize: 10, color: Colors.grey)),
                ],
              ),
            ),
            if (isUnlocked) const Icon(Icons.check_circle_rounded, color: Colors.green),
          ],
        ),
      ),
    );
  }
}
