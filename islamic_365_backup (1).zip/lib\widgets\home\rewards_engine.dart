import 'dart:async';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../../core/theme_manager.dart';

class RewardsEngine extends StatefulWidget {
  const RewardsEngine({super.key});

  @override
  State<RewardsEngine> createState() => _RewardsEngineState();
}

class _RewardsEngineState extends State<RewardsEngine> with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late ScrollController _tickerController;
  late Timer _tickerTimer;

  final List<String> _tickerMessages = [
    'User123 claimed 30 Golds!',
    'Sister Amina earned a Diamond Chest!',
    'Brother Ali reached Gold Tier!',
    'User999 watched all ads for today!',
    'Hafiz Ahmad claimed 50 Golds!',
  ];

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    )..repeat(reverse: true);

    _tickerController = ScrollController();
    WidgetsBinding.instance.addPostFrameCallback((_) => _startTicker());
  }

  void _startTicker() {
    _tickerTimer = Timer.periodic(const Duration(milliseconds: 50), (timer) {
      if (_tickerController.hasClients) {
        double max = _tickerController.position.maxScrollExtent;
        double current = _tickerController.offset;
        if (current >= max) {
          _tickerController.jumpTo(0);
        } else {
          _tickerController.animateTo(
            current + 1.5,
            duration: const Duration(milliseconds: 50),
            curve: Curves.linear,
          );
        }
      }
    });
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _tickerController.dispose();
    _tickerTimer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildOfficialBanner(),
        const SizedBox(height: 24),
        _buildRewardCard(),
        const SizedBox(height: 16),
        _buildVitarTicker(),
      ],
    );
  }

  Widget _buildOfficialBanner() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1B4138), Color(0xFF2E7D32)],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: ThemeManager.goldAccent.withValues(alpha: 0.4), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF1B4138).withValues(alpha: 0.3),
            blurRadius: 15,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Stack(
          children: [
            Positioned(
              right: -20,
              top: -20,
              child: Icon(
                Icons.support_agent,
                size: 100,
                color: Colors.white.withValues(alpha: 0.05),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.2),
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        )
                      ],
                    ),
                    child: Icon(Icons.mark_as_unread_rounded, color: ThemeManager.goldAccent, size: 32),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'OFFICIAL HUB',
                          style: TextStyle(color: ThemeManager.goldAccent, fontWeight: FontWeight.w900, fontSize: 10, letterSpacing: 1),
                        ),
                        Text(
                          'Policy & Support',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18),
                        ),
                        const SizedBox(height: 8),
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: [
                              _buildLink('Ads Policy'),
                              _buildLink('Privacy'),
                              _buildLink('Terms'),
                              _buildLink('About'),
                              _buildLink('Share'),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLink(String label) {
    return Padding(
      padding: const EdgeInsets.only(right: 14),
      child: GestureDetector(
        onTap: () {},
        child: Text(
          label,
          style: TextStyle(
            color: Colors.white.withValues(alpha: 0.7),
            fontSize: 11,
            fontWeight: FontWeight.w600,
            decoration: TextDecoration.underline,
            decorationColor: ThemeManager.goldAccent.withValues(alpha: 0.5),
          ),
        ),
      ),
    );
  }

  Widget _buildRewardCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Rewards Journey',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Theme.of(context).primaryColor),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: ThemeManager.mintGreen,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  'LVL 12',
                  style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: Theme.of(context).primaryColor),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildTier('Bronze', FontAwesomeIcons.box, const Color(0xFFCD7F32), true),
              _buildConnector(true),
              _buildTier('Silver', FontAwesomeIcons.box, const Color(0xFFC0C0C0), false),
              _buildConnector(false),
              _buildTier('Gold', FontAwesomeIcons.box, const Color(0xFFFFD700), false),
              _buildConnector(false),
              _buildTier('Diamond', FontAwesomeIcons.gem, const Color(0xFFB9F2FF), false),
            ],
          ),
          const SizedBox(height: 30),
          AnimatedBuilder(
            animation: _pulseController,
            builder: (context, child) {
              return Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: ThemeManager.goldAccent.withValues(alpha: 0.3 * _pulseController.value),
                      blurRadius: 15,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: ThemeManager.goldAccent,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 18),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                    elevation: 4,
                    shadowColor: ThemeManager.goldAccent.withValues(alpha: 0.5),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.play_circle_fill, size: 20),
                      const SizedBox(width: 10),
                      Text(
                        'Watch Ads (0/6)',
                        style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16, letterSpacing: 0.5),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildTier(String label, dynamic icon, Color color, bool isUnlocked) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.15),
            shape: BoxShape.circle,
            border: Border.all(color: color.withValues(alpha: isUnlocked ? 0.8 : 0.2), width: 2),
          ),
          child: FaIcon((isUnlocked ? icon : FontAwesomeIcons.lock) as FaIconData?, color: color, size: 18),
        ),
        const SizedBox(height: 6),
        Text(
          label,
          style: TextStyle(
            fontSize: 9,
            fontWeight: FontWeight.w900,
            color: isUnlocked ? color : Colors.grey.withValues(alpha: 0.6),
          ),
        ),
      ],
    );
  }

  Widget _buildConnector(bool isFilled) {
    return Expanded(
      child: Container(
        height: 3,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: (isFilled ? ThemeManager.goldAccent : Colors.grey).withValues(alpha: 0.2),
          borderRadius: BorderRadius.circular(2),
        ),
      ),
    );
  }

  Widget _buildVitarTicker() {
    return Container(
      height: 36,
      width: double.infinity,
      decoration: BoxDecoration(
        color: ThemeManager.mintGreen.withValues(alpha: 0.4),
        border: Border.symmetric(horizontal: BorderSide(color: Theme.of(context).primaryColor.withValues(alpha: 0.05))),
      ),
      child: ListView.builder(
        controller: _tickerController,
        scrollDirection: Axis.horizontal,
        physics: const NeverScrollableScrollPhysics(),
        itemBuilder: (context, index) {
          final message = _tickerMessages[index % _tickerMessages.length];
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 8),
            child: Row(
              children: [
                Icon(Icons.flash_on, color: ThemeManager.goldAccent, size: 14),
                const SizedBox(width: 8),
                Text(
                  message,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: Theme.of(context).primaryColor,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

