import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../../core/theme_manager.dart';

class QuranAudioPage extends StatefulWidget {
  const QuranAudioPage({super.key});

  @override
  State<QuranAudioPage> createState() => _QuranAudioPageState();
}

class _QuranAudioPageState extends State<QuranAudioPage> {
  int? _playingIndex;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Quran Audio', style: Theme.of(context).textTheme.titleLarge?.copyWith(
          color: AppColors.primary,
          fontWeight: FontWeight.bold,
        )),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.primary),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          _buildPlayerCard(),
          Expanded(child: _buildAudioList()),
        ],
      ),
    );
  }

  Widget _buildPlayerCard() {
    return Container(
      margin: const EdgeInsets.all(20),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppColors.primary, AppColors.darkGreenAccent],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withValues(alpha: 0.3),
            blurRadius: 15,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Center(
              child: FaIcon(FontAwesomeIcons.music, color: Colors.white, size: 30),
            ),
          ),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Now Playing',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Colors.white70,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  _playingIndex != null ? 'Surah Al-Baqarah' : 'Select a Surah',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: const BoxDecoration(
              color: AppColors.secondary,
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 30),
          ),
        ],
      ),
    );
  }

  Widget _buildAudioList() {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      itemCount: 114,
      itemBuilder: (context, index) {
        final isPlaying = _playingIndex == index;
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: isPlaying ? AppColors.mintGreen.withValues(alpha: 0.4) : Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: isPlaying ? Border.all(color: AppColors.secondary.withValues(alpha: 0.5)) : null,
          ),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            leading: Text(
              '${index + 1}'.padLeft(2, '0'),
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: isPlaying ? AppColors.secondary : AppColors.primary.withValues(alpha: 0.3),
                fontWeight: FontWeight.w900,
              ),
            ),
            title: Text(
              'Surah Name ${index + 1}',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: AppColors.primary,
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: Text(
              'Mishary Rashid Alafasy',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: AppColors.primary.withValues(alpha: 0.5),
              ),
            ),
            trailing: Icon(
              isPlaying ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded,
              color: isPlaying ? AppColors.secondary : AppColors.primary.withValues(alpha: 0.2),
              size: 35,
            ),
            onTap: () => setState(() => _playingIndex = isPlaying ? null : index),
          ),
        );
      },
    );
  }
}
