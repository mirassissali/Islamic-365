
import 'package:flutter_test/flutter_test.dart';

import 'package:islamic_365/main.dart';

void main() {
  testWidgets('Islamic 365 app smoke test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const Islamic365App());

    // Verify that the app title is present.
    expect(find.text('Islamic 365'), findsOneWidget);
  });
}
