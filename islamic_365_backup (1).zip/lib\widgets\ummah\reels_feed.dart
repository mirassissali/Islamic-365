import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../../core/theme_manager.dart';

class ReelsFeed extends StatelessWidget {
  const ReelsFeed({super.key});

  @override
  Widget build(BuildContext context) {
    return PageView.builder(
      scrollDirection: Axis.vertical,
      itemCount: 5,
      itemBuilder: (context, index) {
        return _buildReelItem(context, index);
      },
    );
  }

  Widget _buildReelItem(BuildContext context, int index) {
    return Container(
      color: Colors.black, // Dark background for reels
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Placeholder for Video Player
          Image.network(
            'https://images.unsplash.com/photo-1564121211835-e88c852648ab?w=600&q=80',
            fit: BoxFit.cover,
            color: Colors.black.withValues(alpha: 0.3),
            colorBlendMode: BlendMode.darken,
          ),
          
          // Right Side Overlays (Like, Comment, Share)
          Positioned(
            right: 16,
            bottom: 100,
            child: Column(
              children: [
                _buildOverlayIcon(FaIcon(FontAwesomeIcons.solidHeart, color: Colors.red, size: 30), '12K'),
                const SizedBox(height: 20),
                _buildOverlayIcon(FaIcon(FontAwesomeIcons.solidCommentDots, color: Colors.white, size: 30), '345'),
                const SizedBox(height: 20),
                _buildOverlayIcon(FaIcon(FontAwesomeIcons.share, color: Colors.white, size: 30), 'Share'),
              ],
            ),
          ),

          // Bottom Info Overlay (User Info, Caption)
          Positioned(
            left: 16,
            bottom: 20,
            right: 80, // Leave space for the right overlay icons
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: ThemeManager.mintGreen,
                      radius: 20,
                      child: Icon(Icons.person, color: Theme.of(context).primaryColor),
                    ),
                    const SizedBox(width: 10),
                    const Text(
                      '@islamic_creator',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.white),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Text(
                        'Follow',
                        style: TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                const Text(
                  'Beautiful reflection on Sabr (Patience) and Tawakkul 🕊️ #Islam #Motivation',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 8),
                Row(
                  children: const [
                    Icon(Icons.music_note, color: Colors.white, size: 16),
                    SizedBox(width: 8),
                    Text(
                      'Original Audio - Nasheed',
                      style: TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOverlayIcon(Widget icon, String label) {
    return Column(
      children: [
        icon,
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}
