import 'dart:async';
import 'package:flutter/material.dart';
import 'package:adhan/adhan.dart';
import 'package:intl/intl.dart';
import '../../core/theme_manager.dart';

class PrayerHubHeader extends StatefulWidget {
  final String city;
  const PrayerHubHeader({super.key, this.city = 'Cuttack'});

  @override
  State<PrayerHubHeader> createState() => _PrayerHubHeaderState();
}

class _PrayerHubHeaderState extends State<PrayerHubHeader> with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late Timer _timer;
  PrayerTimes? _prayerTimes;
  Prayer _nextPrayer = Prayer.none;
  Duration _timeLeft = Duration.zero;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _calculatePrayerTimes();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _calculatePrayerTimes();
    });
  }

  void _calculatePrayerTimes() {
    final myCoordinates = Coordinates(20.4625, 85.8830); // Cuttack
    final params = CalculationMethod.karachi.getParameters();
    params.madhab = Madhab.hanafi;
    
    final date = DateComponents.from(DateTime.now());
    final prayerTimes = PrayerTimes(myCoordinates, date, params);
    
    final next = prayerTimes.nextPrayer();
    final nextTime = prayerTimes.timeForPrayer(next);
    
    if (mounted) {
      setState(() {
        _prayerTimes = prayerTimes;
        _nextPrayer = next;
        if (nextTime != null) {
          _timeLeft = nextTime.difference(DateTime.now());
        }
      });
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _timer.cancel();
    super.dispose();
  }

  String _formatDuration(Duration d) {
    if (d.isNegative) return "00:00:00";
    String twoDigits(int n) => n.toString().padLeft(2, "0");
    return "${twoDigits(d.inHours)}:${twoDigits(d.inMinutes.remainder(60))}:${twoDigits(d.inSeconds.remainder(60))}";
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 260,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF004D40), Color(0xFF00695C)],
        ),
        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(40)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            blurRadius: 25,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Stack(
        children: [
          // Masjid Silhouette Background with fade
          Positioned(
            bottom: -10,
            left: 0,
            right: 0,
            child: Opacity(
              opacity: 0.15,
              child: Image.asset(
                'assets/images/masjid_silhouette.png',
                fit: BoxFit.cover,
                height: 160,
              ),
            ),
          ),
          
          // Content
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 60, 24, 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.location_on, color: ThemeManager.goldAccent, size: 14),
                            const SizedBox(width: 4),
                            Text(
                              widget.city.toUpperCase(),
                              style: TextStyle(
                                color: Colors.white70,
                                letterSpacing: 2,
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Upcoming: ${_nextPrayer == Prayer.none ? "Fajr" : _nextPrayer.name.toUpperCase()}',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -0.5,
                          ),
                        ),
                      ],
                    ),
                    _buildCountdownBadge(),
                  ],
                ),
                const Spacer(),
                _buildPrayerRow(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCountdownBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 10,
          )
        ]
      ),
      child: Column(
        children: [
          const Text(
            'COUNTDOWN',
            style: TextStyle(color: Colors.white60, fontSize: 8, fontWeight: FontWeight.w900, letterSpacing: 1),
          ),
          const SizedBox(height: 2),
          Text(
            _formatDuration(_timeLeft),
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w900,
              fontFeatures: [FontFeature.tabularFigures()],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPrayerRow() {
    if (_prayerTimes == null) return const SizedBox.shrink();

    final List<Map<String, dynamic>> prayers = [
      {'name': 'Fajr', 'time': DateFormat.Hm().format(_prayerTimes!.fajr), 'type': Prayer.fajr},
      {'name': 'Dhuhr', 'time': DateFormat.Hm().format(_prayerTimes!.dhuhr), 'type': Prayer.dhuhr},
      {'name': 'Asr', 'time': DateFormat.Hm().format(_prayerTimes!.asr), 'type': Prayer.asr},
      {'name': 'Maghrib', 'time': DateFormat.Hm().format(_prayerTimes!.maghrib), 'type': Prayer.maghrib},
      {'name': 'Isha', 'time': DateFormat.Hm().format(_prayerTimes!.isha), 'type': Prayer.isha},
    ];

    final currentPrayer = _prayerTimes!.currentPrayer();

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: prayers.map((p) => _buildPrayerItem(p, currentPrayer == p['type'])).toList(),
    );
  }

  Widget _buildPrayerItem(Map<String, dynamic> p, bool isActive) {
    return Column(
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            if (isActive)
              ScaleTransition(
                scale: Tween(begin: 1.0, end: 1.6).animate(
                  CurvedAnimation(parent: _pulseController, curve: Curves.easeOutCirc),
                ),
                child: Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: ThemeManager.goldAccent.withValues(alpha: 0.4),
                        blurRadius: 10,
                        spreadRadius: 4,
                      )
                    ],
                  ),
                ),
              ),
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isActive ? ThemeManager.goldAccent : Colors.white.withValues(alpha: 0.08),
                border: Border.all(
                  color: isActive ? Colors.white : Colors.white24,
                  width: isActive ? 2 : 1,
                ),
                boxShadow: isActive ? [
                  BoxShadow(color: ThemeManager.goldAccent.withValues(alpha: 0.3), blurRadius: 10, offset: const Offset(0, 4))
                ] : null,
              ),
              child: Center(
                child: Text(
                  p['time'],
                  style: TextStyle(
                    color: isActive ? Colors.white : Colors.white70,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          p['name'],
          style: TextStyle(
            color: isActive ? Colors.white : Colors.white54,
            fontSize: 11,
            fontWeight: isActive ? FontWeight.w900 : FontWeight.w500,
          ),
        ),
        if (isActive)
          Container(
            margin: const EdgeInsets.only(top: 4),
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: Colors.redAccent,
              borderRadius: BorderRadius.circular(6),
              boxShadow: [
                BoxShadow(color: Colors.redAccent.withValues(alpha: 0.3), blurRadius: 4)
              ]
            ),
            child: const Text(
              'RUNNING',
              style: TextStyle(color: Colors.white, fontSize: 7, fontWeight: FontWeight.w900),
            ),
          ),
      ],
    );
  }
}

