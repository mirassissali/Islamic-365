import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../core/theme_manager.dart';

class QuranScreen extends StatefulWidget {
  const QuranScreen({super.key});

  @override
  State<QuranScreen> createState() => _QuranScreenState();
}

class _QuranScreenState extends State<QuranScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() {
      if (!_tabController.indexIsChanging) {
        setState(() {}); // Rebuild to update settings icon based on active tab
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeManager.backgroundCream,
      appBar: AppBar(
        backgroundColor: ThemeManager.backgroundCream,
        elevation: 0,
        title: Text(
          'Al Quran',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontSize: 24,
            fontWeight: FontWeight.w900,
            color: Theme.of(context).primaryColor,
          ),
        ),
        actions: [
          IconButton(
            icon: FaIcon(
              _tabController.index == 0 
                  ? FontAwesomeIcons.sliders // Read tab settings
                  : FontAwesomeIcons.headphones, // Audio tab settings
              color: Theme.of(context).primaryColor,
              size: 20,
            ),
            onPressed: () {
              // Handle context-aware settings
              final tabName = _tabController.index == 0 ? 'Read' : 'Audio';
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('$tabName Settings Opened')),
              );
            },
          ),
          const SizedBox(width: 8),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Theme.of(context).primaryColor,
          indicatorWeight: 3,
          labelColor: Theme.of(context).primaryColor,
          unselectedLabelColor: Colors.grey,
          labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          tabs: const [
            Tab(text: 'Al Quran Read'),
            Tab(text: 'Al Quran Audio'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          const _QuranReadTab(),
          const _QuranAudioTab(),
        ],
      ),
    );
  }
}

class _QuranReadTab extends StatefulWidget {
  const _QuranReadTab();

  @override
  State<_QuranReadTab> createState() => _QuranReadTabState();
}

class _QuranReadTabState extends State<_QuranReadTab> {
  final List<String> _filters = ['Language', 'Surah', 'Juz', 'Favorite', 'Bookmark'];
  int _selectedFilterIndex = 1; // Default to Surah

  void _showLanguageBottomSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: ThemeManager.backgroundCream,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Select Translation',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).primaryColor,
                ),
              ),
              const SizedBox(height: 16),
              ...['English (Sahih International)', 'Urdu', 'Hindi', 'Bengali'].map((lang) {
                return ListTile(
                  title: Text(lang, style: TextStyle(color: Theme.of(context).primaryColor)),
                  trailing: lang == 'English (Sahih International)' 
                      ? Icon(Icons.check_circle, color: ThemeManager.goldAccent) 
                      : null,
                  onTap: () => Navigator.pop(context),
                );
              }),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Sub-menu
        SizedBox(
          height: 60,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            itemCount: _filters.length,
            itemBuilder: (context, index) {
              final isSelected = _selectedFilterIndex == index;
              return GestureDetector(
                onTap: () {
                  if (_filters[index] == 'Language') {
                    _showLanguageBottomSheet();
                  } else {
                    setState(() => _selectedFilterIndex = index);
                  }
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  decoration: BoxDecoration(
                    color: isSelected ? Theme.of(context).primaryColor : Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected ? Theme.of(context).primaryColor : Colors.grey.withValues(alpha: 0.2),
                    ),
                    boxShadow: isSelected ? [
                      BoxShadow(
                        color: Theme.of(context).primaryColor.withValues(alpha: 0.3),
                        blurRadius: 8,
                        offset: const Offset(0, 4),
                      )
                    ] : null,
                  ),
                  child: Center(
                    child: Text(
                      _filters[index],
                      style: TextStyle(
                        color: isSelected ? Colors.white : Colors.grey[700],
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        
        // List
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            itemCount: 114, // 114 Surahs placeholder
            itemBuilder: (context, index) {
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.04),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    // Surah Number Badge
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: ThemeManager.mintGreen,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Center(
                        child: Text(
                          '${index + 1}',
                          style: TextStyle(
                            color: Theme.of(context).primaryColor,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    // Title and Subtitle
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Surah Name ${index + 1}',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Theme.of(context).primaryColor,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Meccan • 7 Verses',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Arabic Name
                    Text(
                      'سُورَة ${index + 1}',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: ThemeManager.goldAccent,
                        fontFamily: 'Amiri', // Assuming an Arabic font might be used, fallback is okay
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _QuranAudioTab extends StatefulWidget {
  const _QuranAudioTab();

  @override
  State<_QuranAudioTab> createState() => _QuranAudioTabState();
}

class _QuranAudioTabState extends State<_QuranAudioTab> {
  int? _playingIndex;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Sub-menu for audio can be similar or omitted based on design. Let's include Reciter instead of Language.
        SizedBox(
          height: 60,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            children: [
              _buildAudioFilterChip('Reciter', false),
              _buildAudioFilterChip('Surah', true),
              _buildAudioFilterChip('Juz', false),
              _buildAudioFilterChip('Downloaded', false),
            ],
          ),
        ),

        // Audio List
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            itemCount: 114,
            itemBuilder: (context, index) {
              final isPlaying = _playingIndex == index;
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: isPlaying ? ThemeManager.mintGreen : Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: isPlaying ? Border.all(color: ThemeManager.goldAccent.withValues(alpha: 0.5)) : null,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.04),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    // Play/Pause Button
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          _playingIndex = isPlaying ? null : index;
                        });
                      },
                      child: Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: isPlaying ? ThemeManager.goldAccent : ThemeManager.backgroundCream,
                          shape: BoxShape.circle,
                        ),
                        child: Center(
                          child: FaIcon(
                            isPlaying ? FontAwesomeIcons.pause : FontAwesomeIcons.play,
                            color: isPlaying ? Colors.white : Theme.of(context).primaryColor,
                            size: 16,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    // Title and Subtitle
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Surah Name ${index + 1}',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Theme.of(context).primaryColor,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Mishary Rashid Alafasy',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Duration / Size
                    Text(
                      '4:3${index % 10}',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: Theme.of(context).primaryColor,
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildAudioFilterChip(String label, bool isSelected) {
    return Container(
      margin: const EdgeInsets.only(right: 12),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      decoration: BoxDecoration(
        color: isSelected ? Theme.of(context).primaryColor : Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isSelected ? Theme.of(context).primaryColor : Colors.grey.withValues(alpha: 0.2),
        ),
        boxShadow: isSelected ? [
          BoxShadow(
            color: Theme.of(context).primaryColor.withValues(alpha: 0.3),
            blurRadius: 8,
            offset: const Offset(0, 4),
          )
        ] : null,
      ),
      child: Center(
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.grey[700],
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
      ),
    );
  }
}
