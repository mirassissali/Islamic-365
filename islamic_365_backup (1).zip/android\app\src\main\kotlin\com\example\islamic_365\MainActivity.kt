package com.example.islamic_365

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
