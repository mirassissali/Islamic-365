import 'package:flutter/material.dart';

class MarqueeRow extends StatefulWidget {
  final List<Widget> items;
  final bool reverse;
  final double speed;
  final bool isPaused;
  final VoidCallback onInteraction;

  const MarqueeRow({
    super.key,
    required this.items,
    this.reverse = false,
    this.speed = 30.0,
    required this.isPaused,
    required this.onInteraction,
  });

  @override
  State<MarqueeRow> createState() => _MarqueeRowState();
}

class _MarqueeRowState extends State<MarqueeRow> with SingleTickerProviderStateMixin {
  late ScrollController _scrollController;
  late AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    )..repeat();

    _animationController.addListener(_scrollListener);
  }

  void _scrollListener() {
    if (!widget.isPaused && _scrollController.hasClients) {
      double maxScroll = _scrollController.position.maxScrollExtent;
      double currentScroll = _scrollController.offset;
      double delta = widget.speed / 60.0; // Assuming 60fps

      if (widget.reverse) {
        if (currentScroll <= 0) {
          _scrollController.jumpTo(maxScroll / 2);
        } else {
          _scrollController.jumpTo(currentScroll - delta);
        }
      } else {
        if (currentScroll >= maxScroll) {
          _scrollController.jumpTo(maxScroll / 2);
        } else {
          _scrollController.jumpTo(currentScroll + delta);
        }
      }
    }
  }

  @override
  void dispose() {
    _animationController.removeListener(_scrollListener);
    _animationController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // To create an infinite feel, we triple the items
    final tripledItems = [...widget.items, ...widget.items, ...widget.items];

    return SizedBox(
      height: 80,
      child: GestureDetector(
        onTapDown: (_) => widget.onInteraction(),
        onLongPress: () => widget.onInteraction(),
        child: ListView.builder(
          controller: _scrollController,
          scrollDirection: Axis.horizontal,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: tripledItems.length,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: tripledItems[index],
            );
          },
        ),
      ),
    );
  }
}
