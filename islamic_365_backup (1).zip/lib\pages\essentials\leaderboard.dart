import 'package:flutter/material.dart';
import '../../core/theme_manager.dart';

class LeaderboardPage extends StatefulWidget {
  const LeaderboardPage({super.key});

  @override
  State<LeaderboardPage> createState() => _LeaderboardPageState();
}

class _LeaderboardPageState extends State<LeaderboardPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Leaderboard', style: Theme.of(context).textTheme.titleLarge?.copyWith(
          color: AppColors.primary,
          fontWeight: FontWeight.bold,
        )),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.primary),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          _buildTopThree(),
          const SizedBox(height: 20),
          Expanded(child: _buildRankList()),
        ],
      ),
    );
  }

  Widget _buildTopThree() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          _buildPodiumItem('Omar', '2,450', 2, 80),
          _buildPodiumItem('Fatima', '3,120', 1, 100),
          _buildPodiumItem('Ali', '2,100', 3, 70),
        ],
      ),
    );
  }

  Widget _buildPodiumItem(String name, String points, int rank, double height) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: rank == 1 ? Colors.orange : Colors.grey, width: 2),
          ),
          child: CircleAvatar(
            radius: rank == 1 ? 40 : 30,
            backgroundColor: AppColors.mintGreen.withValues(alpha: 0.3),
            child: Text(name[0], style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.bold, fontSize: rank == 1 ? 24 : 18)),
          ),
        ),
        const SizedBox(height: 12),
        Text(name, style: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.bold)),
        Text('$points pts', style: TextStyle(color: AppColors.secondary, fontSize: 10, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Container(
          width: 60,
          height: height,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [AppColors.primary.withValues(alpha: rank == 1 ? 0.8 : 0.4), AppColors.primary.withValues(alpha: 0.1)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
          ),
          child: Center(
            child: Text('#$rank', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ),
      ],
    );
  }

  Widget _buildRankList() {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(40)),
      ),
      child: ListView.builder(
        padding: const EdgeInsets.all(30),
        itemCount: 10,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 20),
            child: Row(
              children: [
                Text('${index + 4}', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.grey, fontWeight: FontWeight.bold)),
                const SizedBox(width: 20),
                CircleAvatar(
                  radius: 20,
                  backgroundColor: AppColors.background,
                  child: const Icon(Icons.person, color: AppColors.primary, size: 20),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Text('User ${index + 4}', style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold)),
                ),
                Text('1,${900 - (index * 50)}', style: const TextStyle(color: AppColors.secondary, fontWeight: FontWeight.bold)),
              ],
            ),
          );
        },
      ),
    );
  }
}
