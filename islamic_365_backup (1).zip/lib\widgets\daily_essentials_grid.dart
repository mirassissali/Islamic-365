import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../core/theme_manager.dart';

class DailyEssentialsGrid extends StatelessWidget {
  const DailyEssentialsGrid({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> items = [
      {'title': '14 RAMADAN', 'icon': FontAwesomeIcons.calendar, 'color': Theme.of(context).primaryColor, 'bg': ThemeManager.mintGreen},
      {'title': 'TASBIH 33', 'icon': FontAwesomeIcons.fan, 'color': Theme.of(context).primaryColor, 'bg': ThemeManager.backgroundCream},
      {'title': 'SADAQAH', 'icon': FontAwesomeIcons.handHoldingHeart, 'color': ThemeManager.goldAccent, 'bg': ThemeManager.backgroundCream},
      {'title': 'ZAKAT', 'icon': FontAwesomeIcons.calculator, 'color': ThemeManager.goldAccent, 'bg': ThemeManager.backgroundCream},
      {'title': 'QIBLA', 'icon': FontAwesomeIcons.compass, 'color': Theme.of(context).primaryColor, 'bg': ThemeManager.mintGreen},
      {'title': 'HADITH', 'icon': FontAwesomeIcons.bookOpen, 'color': Theme.of(context).primaryColor, 'bg': ThemeManager.backgroundCream},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                'Daily Essentials',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontSize: 22,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: ThemeManager.lightYellow,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'SWIPE FOR MORE',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: ThemeManager.goldAccent,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.2,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 120,
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            scrollDirection: Axis.horizontal,
            itemCount: items.length,
            separatorBuilder: (context, index) => const SizedBox(width: 12),
            itemBuilder: (context, index) {
              final item = items[index];
              return Column(
                children: [
                  Container(
                    width: 76,
                    height: 76,
                    decoration: BoxDecoration(
                      color: item['bg'],
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: Theme.of(context).primaryColor.withValues(alpha: 0.05),
                      ),
                      boxShadow: [
                        if (item['bg'] == ThemeManager.backgroundCream)
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.03),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                      ],
                    ),
                    child: Center(
                      child: FaIcon(
                        item['icon'],
                        color: item['color'],
                        size: 24,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    item['title'],
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.1,
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ],
    );
  }
}
