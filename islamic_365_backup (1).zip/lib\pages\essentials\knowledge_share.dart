import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../../core/theme_manager.dart';

class KnowledgeSharePage extends StatefulWidget {
  const KnowledgeSharePage({super.key});

  @override
  State<KnowledgeSharePage> createState() => _KnowledgeSharePageState();
}

class _KnowledgeSharePageState extends State<KnowledgeSharePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Knowledge Share', style: Theme.of(context).textTheme.titleLarge?.copyWith(
          color: AppColors.primary,
          fontWeight: FontWeight.bold,
        )),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.primary),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          _buildFeaturedArticle(),
          const SizedBox(height: 32),
          _buildSectionHeader('Explore Topics'),
          const SizedBox(height: 16),
          _buildTopicGrid(),
          const SizedBox(height: 32),
          _buildSectionHeader('Recent Community Posts'),
          const SizedBox(height: 16),
          _buildCommunityPost(),
        ],
      ),
    );
  }

  Widget _buildFeaturedArticle() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 180,
            decoration: const BoxDecoration(
              color: AppColors.primary,
              borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
            ),
            child: const Center(
              child: FaIcon(FontAwesomeIcons.bookOpenReader, color: Colors.white, size: 50),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppColors.mintGreen.withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text('FEATURED', style: TextStyle(color: AppColors.primary, fontSize: 10, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 12),
                Text(
                  'The Importance of Patience in Islam',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text(
                  'A deep dive into the concept of Sabr and how it strengthens our faith...',
                  style: AppTextTheme.caption(context),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
        Text('See All', style: TextStyle(color: AppColors.secondary, fontSize: 12, fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _buildTopicGrid() {
    final topics = ['Fiqh', 'History', 'Prophets', 'Ethics', 'Aqidah', 'Contemporary'];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1,
      ),
      itemCount: topics.length,
      itemBuilder: (context, index) {
        return Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppColors.primary.withValues(alpha: 0.05)),
          ),
          child: Center(
            child: Text(topics[index], style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
          ),
        );
      },
    );
  }

  Widget _buildCommunityPost() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
      ),
      child: ListTile(
        contentPadding: EdgeInsets.zero,
        leading: const CircleAvatar(backgroundColor: AppColors.background, child: Icon(Icons.person, color: AppColors.primary)),
        title: Text('Brother Ahmed shared a quote', style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold)),
        subtitle: const Text('2 hours ago'),
        trailing: const Icon(Icons.share_rounded, size: 20, color: AppColors.secondary),
      ),
    );
  }
}
