import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../../core/theme_manager.dart';

class TasbeehPage extends StatefulWidget {
  const TasbeehPage({super.key});

  @override
  State<TasbeehPage> createState() => _TasbeehPageState();
}

class _TasbeehPageState extends State<TasbeehPage> with SingleTickerProviderStateMixin {
  int _count = 0;
  int _limit = 33;
  late AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 100),
    );
  }

  void _increment() {
    setState(() {
      _count++;
      if (_count > _limit) _count = 1;
    });
    _animationController.forward(from: 0);
  }

  void _reset() {
    setState(() => _count = 0);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Digital Tasbeeh', style: Theme.of(context).textTheme.titleLarge?.copyWith(
          color: AppColors.primary,
          fontWeight: FontWeight.bold,
        )),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.primary),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: AppColors.secondary),
            onPressed: _reset,
          ),
        ],
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _buildCounterDisplay(),
          const SizedBox(height: 60),
          _buildTapButton(),
          const SizedBox(height: 40),
          _buildLimitSettings(),
        ],
      ),
    );
  }

  Widget _buildCounterDisplay() {
    return Column(
      children: [
        Text(
          'SUBHANALLAH',
          style: Theme.of(context).textTheme.labelLarge?.copyWith(
            color: AppColors.secondary,
            letterSpacing: 4,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 24),
        Container(
          width: 220,
          height: 220,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: AppColors.primary.withValues(alpha: 0.08),
                blurRadius: 30,
                spreadRadius: 5,
              ),
            ],
            border: Border.all(color: AppColors.mintGreen.withValues(alpha: 0.5), width: 10),
          ),
          child: Center(
            child: ScaleTransition(
              scale: Tween<double>(begin: 1.0, end: 1.15).animate(
                CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
              ),
              child: Text(
                '$_count',
                style: Theme.of(context).textTheme.displayLarge?.copyWith(
                  fontSize: 80,
                  fontWeight: FontWeight.w900,
                  color: AppColors.primary,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 24),
        Text(
          'Target: $_limit',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: AppColors.primary.withValues(alpha: 0.5),
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildTapButton() {
    return GestureDetector(
      onTap: _increment,
      child: Container(
        width: 120,
        height: 120,
        decoration: BoxDecoration(
          color: AppColors.primary,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.withValues(alpha: 0.3),
              blurRadius: 20,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: const Center(
          child: FaIcon(FontAwesomeIcons.handPointer, color: Colors.white, size: 35),
        ),
      ),
    );
  }

  Widget _buildLimitSettings() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [33, 99, 1000].map((l) {
        final isSelected = _limit == l;
        return GestureDetector(
          onTap: () => setState(() => _limit = l),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 8),
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            decoration: BoxDecoration(
              color: isSelected ? AppColors.secondary : Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.secondary.withValues(alpha: 0.2)),
            ),
            child: Text(
              '$l',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: isSelected ? Colors.white : AppColors.primary,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
}
