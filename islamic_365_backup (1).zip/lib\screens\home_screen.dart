import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../core/theme_manager.dart';
import '../models/daily_essential.dart';
import '../widgets/home/prayer_hub_header.dart';
import '../widgets/home/infinite_marquee.dart';
import '../widgets/home/rewards_engine.dart';
import '../widgets/home/community_content.dart';
import '../widgets/home/azkar_module.dart';
import 'quran_screen.dart';
import 'ummah_screen.dart';
import 'community_screen.dart';
import 'profile_screen.dart';
import 'dart:ui';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  final List<DailyEssential> _essentials = [
    // Row 1
    DailyEssential(label: 'Quran Read', icon: FontAwesomeIcons.bookOpen, category: DailyEssentialCategory.deen),
    DailyEssential(label: 'Quran Audio', icon: FontAwesomeIcons.headphones, category: DailyEssentialCategory.deen),
    DailyEssential(label: '99 Names', icon: FontAwesomeIcons.starAndCrescent, category: DailyEssentialCategory.deen),
    DailyEssential(label: 'Hadith', icon: FontAwesomeIcons.book, category: DailyEssentialCategory.deen),
    DailyEssential(label: 'Dua Bank', icon: FontAwesomeIcons.handsPraying, category: DailyEssentialCategory.deen),
    DailyEssential(label: 'Tafsir Hub', icon: FontAwesomeIcons.magnifyingGlass, category: DailyEssentialCategory.deen),
    DailyEssential(label: 'Tasbeeh', icon: FontAwesomeIcons.ellipsis, category: DailyEssentialCategory.tools),
    DailyEssential(label: 'Qibla', icon: FontAwesomeIcons.compass, category: DailyEssentialCategory.tools),
    DailyEssential(label: 'Zakat Calc', icon: FontAwesomeIcons.calculator, category: DailyEssentialCategory.tools),
    DailyEssential(label: 'Hijri Date', icon: FontAwesomeIcons.calendarDays, category: DailyEssentialCategory.tools),
    DailyEssential(label: 'Masjid Find', icon: FontAwesomeIcons.mosque, category: DailyEssentialCategory.tools),
    DailyEssential(label: 'Halal Find', icon: FontAwesomeIcons.bowlFood, category: DailyEssentialCategory.tools),
    // Row 2
    DailyEssential(label: 'Islamic Quiz', icon: FontAwesomeIcons.puzzlePiece, category: DailyEssentialCategory.earn),
    DailyEssential(label: 'Leaderboard', icon: FontAwesomeIcons.trophy, category: DailyEssentialCategory.earn),
    DailyEssential(label: 'Refer & Earn', icon: FontAwesomeIcons.shareNodes, category: DailyEssentialCategory.earn),
    DailyEssential(label: 'Knowledge', icon: FontAwesomeIcons.graduationCap, category: DailyEssentialCategory.earn),
    DailyEssential(label: 'Daily Streak', icon: FontAwesomeIcons.fire, category: DailyEssentialCategory.earn),
    DailyEssential(label: 'Events', icon: FontAwesomeIcons.calendarCheck, category: DailyEssentialCategory.social),
    DailyEssential(label: 'Sadaqah', icon: FontAwesomeIcons.handHoldingHeart, category: DailyEssentialCategory.social),
    DailyEssential(label: 'Hajj Guide', icon: FontAwesomeIcons.kaaba, category: DailyEssentialCategory.social),
    DailyEssential(label: 'Community', icon: FontAwesomeIcons.newspaper, category: DailyEssentialCategory.social),
    DailyEssential(label: 'Store', icon: FontAwesomeIcons.shop, category: DailyEssentialCategory.social),
    DailyEssential(label: 'Wallet', icon: FontAwesomeIcons.wallet, category: DailyEssentialCategory.social),
    DailyEssential(label: 'Donation', icon: FontAwesomeIcons.heart, category: DailyEssentialCategory.social),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeManager.backgroundCream,
      extendBody: true,
      body: _buildBody(),
      bottomNavigationBar: _buildGlassBottomNav(),
    );
  }

  Widget _buildBody() {
    switch (_currentIndex) {
      case 0:
        return _buildHomeTab();
      case 1:
        return const QuranScreen();
      case 2:
        return const UmmahScreen();
      case 3:
        return const CommunityScreen();
      case 4:
        return const ProfileScreen();
      default:
        return _buildHomeTab();
    }
  }

  Widget _buildHomeTab() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const PrayerHubHeader(city: 'Cuttack'),
          const SizedBox(height: 32),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Daily Essentials',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    color: Theme.of(context).primaryColor,
                  ),
                ),
                Container(
                  height: 3,
                  width: 40,
                  decoration: BoxDecoration(
                    color: ThemeManager.goldAccent,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          InfiniteMarqueeSection(essentials: _essentials),
          const SizedBox(height: 40),
          const RewardsEngine(),
          const SizedBox(height: 40),
          const CommunityContent(),
          const SizedBox(height: 40),
          const AzkarModule(),
          const SizedBox(height: 140),
        ],
      ),
    );
  }

  Widget _buildGlassBottomNav() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 30),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(30),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Container(
            height: 70,
            decoration: BoxDecoration(
              color: const Color(0xFF1B4138).withValues(alpha: 0.85),
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.2),
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: BottomNavigationBar(
              currentIndex: _currentIndex,
              onTap: (index) {
                if (_currentIndex == 2 && index == 2) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Upload Section Opened')),
                  );
                } else {
                  setState(() => _currentIndex = index);
                }
              },
              backgroundColor: Colors.transparent,
              type: BottomNavigationBarType.fixed,
              selectedItemColor: ThemeManager.goldAccent,
              unselectedItemColor: Colors.white38,
              showUnselectedLabels: false,
              elevation: 0,
              items: [
                const BottomNavigationBarItem(icon: Icon(Icons.home_max_rounded), label: 'Home'),
                const BottomNavigationBarItem(icon: Icon(Icons.menu_book_rounded), label: 'Quran'),
                BottomNavigationBarItem(
                  icon: Icon(_currentIndex == 2 ? Icons.add_circle : Icons.mosque_rounded),
                  label: _currentIndex == 2 ? 'Post' : 'Ummah',
                ),
                const BottomNavigationBarItem(icon: Icon(Icons.people_alt_rounded), label: 'Social'),
                const BottomNavigationBarItem(icon: Icon(Icons.person_pin_rounded), label: 'Profile'),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
