import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../core/theme_manager.dart';

class FeaturedSurahs extends StatelessWidget {
  const FeaturedSurahs({super.key});

  @override
  Widget build(BuildContext context) {
    // Placeholder: Replace with real data from Supabase backend
    final List<Map<String, dynamic>> surahs = [
      {
        'number': 36,
        'name': 'Yaseen',
        'info': '83 Verses • The Heart of Quran',
        'bg': ThemeManager.mintGreen,
      },
      {
        'number': 55,
        'name': 'Ar-Rahman',
        'info': '78 Verses • The Most Merciful',
        'bg': ThemeManager.mintGreen,
      },
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            'Featured Surahs',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontSize: 22,
            ),
          ),
        ),
        const SizedBox(height: 16),
        ...surahs.map(
          (surah) => Container(
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.03),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              children: [
                // Surah number circle
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: surah['bg'],
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      '${surah['number']}',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontSize: 18,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                // Title and subtitle
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        surah['name'] as String,
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontSize: 18,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        surah['info'] as String,
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context).primaryColor.withValues(alpha: 0.5),
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
                // Play button
                GestureDetector(
                  onTap: () {
                    // Placeholder: Navigate to Surah player screen
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Playing ${surah['name']} - Coming soon')),
                    );
                  },
                  child: Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: Theme.of(context).primaryColor,
                      shape: BoxShape.circle,
                    ),
                    child: const FaIcon(
                      FontAwesomeIcons.play,
                      color: Colors.white,
                      size: 16,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
