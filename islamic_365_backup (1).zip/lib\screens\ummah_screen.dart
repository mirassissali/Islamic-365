import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../widgets/ummah/videos_feed.dart';
import '../widgets/ummah/reels_feed.dart';

class UmmahScreen extends StatefulWidget {
  const UmmahScreen({super.key});

  @override
  State<UmmahScreen> createState() => _UmmahScreenState();
}

class _UmmahScreenState extends State<UmmahScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent, // Inherits from MainLayout background
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'Ummah Feed',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w900,
            color: Theme.of(context).primaryColor,
          ),
        ),
        actions: [
          IconButton(
            icon: FaIcon(
              FontAwesomeIcons.userGroup,
              color: Theme.of(context).primaryColor,
              size: 20,
            ),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Following/Users')),
              );
            },
          ),
          IconButton(
            icon: FaIcon(
              FontAwesomeIcons.solidCommentDots,
              color: Theme.of(context).primaryColor,
              size: 20,
            ),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Messages')),
              );
            },
          ),
          IconButton(
            icon: FaIcon(
              FontAwesomeIcons.gear,
              color: Theme.of(context).primaryColor,
              size: 20,
            ),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Ummah Preferences')),
              );
            },
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Theme.of(context).primaryColor,
          indicatorWeight: 3,
          labelColor: Theme.of(context).primaryColor,
          unselectedLabelColor: Colors.black38,
          labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          tabs: const [
            Tab(text: 'Videos'),
            Tab(text: 'Reels'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [
          VideosFeed(),
          ReelsFeed(),
        ],
      ),
    );
  }
}
