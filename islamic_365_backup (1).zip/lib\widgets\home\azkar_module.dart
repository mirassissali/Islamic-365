import 'package:flutter/material.dart';
import '../../core/theme_manager.dart';

class AzkarModule extends StatefulWidget {
  const AzkarModule({super.key});

  @override
  State<AzkarModule> createState() => _AzkarModuleState();
}

class _AzkarModuleState extends State<AzkarModule> {
  int _selectedTab = 0;

  Map<String, dynamic> _getContextualData() {
    final hour = DateTime.now().hour;
    if (hour >= 4 && hour < 12) {
      return {
        'title': 'Morning Adhkar',
        'subtitle': 'SABAH AL-KHAYR',
        'icon': Icons.wb_twilight_rounded,
        'color': const Color(0xFFE1F5FE),
        'items': [
          {'text': 'Ayat al-Kursi', 'count': '1 time', 'desc': 'Protection for the day'},
          {'text': 'SubhanAllah wa bihamdihi', 'count': '100 times', 'desc': 'Sins forgiven like sea foam'},
        ]
      };
    } else if (hour >= 12 && hour < 18) {
      return {
        'title': 'Daily Remembrance',
        'subtitle': 'DHIKR ALLAH',
        'icon': Icons.wb_sunny_rounded,
        'color': const Color(0xFFFFFDE7),
        'items': [
          {'text': 'Astaghfirullah', 'count': '100 times', 'desc': 'Seeking continuous mercy'},
          {'text': 'SubhanAllah wa bihamdihi', 'count': '100 times', 'desc': 'Heavier on the scale'},
        ]
      };
    } else {
      return {
        'title': 'Evening Adhkar',
        'subtitle': 'MASA AL-KHAYR',
        'icon': Icons.dark_mode_rounded,
        'color': const Color(0xFFF3E5F5),
        'items': [
          {'text': 'Al-Mu’awwidhatayn', 'count': '3 times', 'desc': 'Protection before sleep'},
          {'text': 'Bismillahi-lladhi la yadurru...', 'count': '3 times', 'desc': 'Safe from all harm'},
        ]
      };
    }
  }

  @override
  Widget build(BuildContext context) {
    final data = _getContextualData();
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(32),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(data),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
            child: Column(
              children: [
                _buildTabs(),
                const SizedBox(height: 24),
                ... (data['items'] as List).map((item) => _buildAzkarItem(item['text'], item['count'], item['desc'])),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(Map<String, dynamic> data) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: data['color'],
        borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(data['icon'], color: Theme.of(context).primaryColor, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  data['subtitle'],
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    color: ThemeManager.goldAccent,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  data['title'],
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    color: Theme.of(context).primaryColor,
                  ),
                ),
              ],
            ),
          ),
          Icon(Icons.keyboard_arrow_right_rounded, color: Theme.of(context).primaryColor),
        ],
      ),
    );
  }

  Widget _buildTabs() {
    final tabs = ['General', 'Protection', 'Gratitude', 'Forgiveness'];
    return Container(
      margin: const EdgeInsets.only(top: 24),
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: tabs.length,
        separatorBuilder: (context, index) => const SizedBox(width: 12),
        itemBuilder: (context, index) {
          bool isSelected = _selectedTab == index;
          return GestureDetector(
            onTap: () => setState(() => _selectedTab = index),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              padding: const EdgeInsets.symmetric(horizontal: 16),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: isSelected ? Theme.of(context).primaryColor : ThemeManager.mintGreen.withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Text(
                tabs[index],
                style: TextStyle(
                  color: isSelected ? Colors.white : Theme.of(context).primaryColor,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildAzkarItem(String title, String count, String desc) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: ThemeManager.mintGreen.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: ThemeManager.mintGreen.withValues(alpha: 0.2)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 15,
                    color: Theme.of(context).primaryColor,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  desc,
                  style: TextStyle(
                    color: Colors.grey.shade600,
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  blurRadius: 4,
                )
              ],
            ),
            child: Text(
              count,
              style: TextStyle(
                color: ThemeManager.goldAccent,
                fontWeight: FontWeight.w900,
                fontSize: 10,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

