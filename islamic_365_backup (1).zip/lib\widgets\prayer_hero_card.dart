import 'package:flutter/material.dart';
import 'package:adhan/adhan.dart';
import '../core/theme_manager.dart';

class PrayerHeroCard extends StatefulWidget {
  const PrayerHeroCard({super.key});

  @override
  State<PrayerHeroCard> createState() => _PrayerHeroCardState();
}

class _PrayerHeroCardState extends State<PrayerHeroCard> {
  PrayerTimes? _prayerTimes;
  Prayer? _nextPrayer;

  @override
  void initState() {
    super.initState();
    _calculatePrayerTimes();
  }

  void _calculatePrayerTimes() {
    final coordinates = Coordinates(20.4625, 85.8830); // Cuttack, Odisha
    final params = CalculationMethod.karachi.getParameters();
    params.madhab = Madhab.hanafi;

    final prayerTimes = PrayerTimes.today(coordinates, params);

    setState(() {
      _prayerTimes = prayerTimes;
      _nextPrayer = prayerTimes.nextPrayer();
    });
  }

  String _formatTime(DateTime? time) {
    if (time == null) return '--:--';
    final hour = time.hour > 12 ? time.hour - 12 : (time.hour == 0 ? 12 : time.hour);
    final minute = time.minute.toString().padLeft(2, '0');
    final amPm = time.hour >= 12 ? 'PM' : 'AM';
    return '$hour:$minute $amPm';
  }

  String _prayerName(Prayer prayer) {
    switch (prayer) {
      case Prayer.fajr: return 'Fajr';
      case Prayer.sunrise: return 'Sunrise';
      case Prayer.dhuhr: return 'Dhuhr';
      case Prayer.asr: return 'Asr';
      case Prayer.maghrib: return 'Maghrib';
      case Prayer.isha: return 'Isha';
      case Prayer.none: return 'None';
    }
  }

  @override
  Widget build(BuildContext context) {
    final prayerName = _nextPrayer != null && _nextPrayer != Prayer.none
        ? _prayerName(_nextPrayer!)
        : 'Isha';
    
    DateTime? prayerTimeObj;
    if (_nextPrayer == Prayer.fajr) {
      prayerTimeObj = _prayerTimes?.fajr;
    } else if (_nextPrayer == Prayer.dhuhr) {
      prayerTimeObj = _prayerTimes?.dhuhr;
    } else if (_nextPrayer == Prayer.asr) {
      prayerTimeObj = _prayerTimes?.asr;
    } else if (_nextPrayer == Prayer.maghrib) {
      prayerTimeObj = _prayerTimes?.maghrib;
    } else if (_nextPrayer == Prayer.isha) {
      prayerTimeObj = _prayerTimes?.isha;
    } else {
      prayerTimeObj = _prayerTimes?.isha;
    }

    final timeString = _formatTime(prayerTimeObj);

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          colors: [ThemeManager.mintGreen, ThemeManager.lightYellow],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.location_on, size: 14, color: Theme.of(context).primaryColor),
                      const SizedBox(width: 4),
                      Text(
                        'CUTTACK, ODISHA',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context).primaryColor,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    prayerName,
                    style: Theme.of(context).textTheme.displayLarge?.copyWith(
                      fontSize: 32,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    timeString,
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      fontSize: 18,
                    ),
                  ),
                  const SizedBox(height: 24),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.05),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: ThemeManager.goldAccent,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'ENDS IN 2H 45M',
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.1,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: ClipRRect(
              borderRadius: const BorderRadius.only(
                topRight: Radius.circular(24),
                bottomRight: Radius.circular(24),
              ),
              child: Container(
                height: 180,
                color: const Color(0xFF1E2A25), // Dark placeholder background
                child: const Center(
                  child: Icon(
                    Icons.person_outline,
                    color: ThemeManager.mintGreen,
                    size: 64,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
