import 'package:flutter/material.dart';
import '../models/daily_essential.dart';

class CoinWidget extends StatelessWidget {
  final CoinTier tier;
  final double size;

  const CoinWidget({
    super.key,
    required this.tier,
    this.size = 24.0,
  });

  @override
  Widget build(BuildContext context) {
    List<Color> gradientColors;
    switch (tier) {
      case CoinTier.bronze:
        gradientColors = [const Color(0xFFCD7F32), const Color(0xFF804A00)];
        break;
      case CoinTier.silver:
        gradientColors = [const Color(0xFFC0C0C0), const Color(0xFF707070)];
        break;
      case CoinTier.gold:
        gradientColors = [const Color(0xFFFFD700), const Color(0xFFB8860B)];
        break;
      case CoinTier.diamond:
        gradientColors = [const Color(0xFFB9F2FF), const Color(0xFF00BFFF)];
        break;
    }

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          colors: gradientColors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.2),
            blurRadius: 4,
            offset: const Offset(1, 1),
          ),
        ],
        border: Border.all(color: Colors.white.withValues(alpha: 0.5), width: 1),
      ),
      child: Center(
        child: Icon(
          Icons.star,
          size: size * 0.6,
          color: Colors.white.withValues(alpha: 0.8),
        ),
      ),
    );
  }
}
