import 'package:flutter/material.dart';

enum DailyEssentialCategory { deen, earn, tools, social }
enum CoinTier { bronze, silver, gold, diamond }

class DailyEssential {
  final String label;
  final dynamic icon;
  final DailyEssentialCategory category;
  final Color? highlightColor;

  DailyEssential({
    required this.label,
    required this.icon,
    required this.category,
    this.highlightColor,
  });
}
