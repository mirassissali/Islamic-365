import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ThemeManager {
  // Core Colors
  static const Color backgroundCream = Color(0xFFF8F5F0);
  static const Color darkGreen = Color(0xFF1B4138);
  static const Color goldAccent = Color(0xFFCBA142);
  static const Color mintGreen = Color(0xFFE2F4EB);
  static const Color lightYellow = Color(0xFFF9EDD4);

  // Rewards Tier Colors
  static const Color bronzeTier = Color(0xFFCD7F32);
  static const Color silverTier = Color(0xFFC0C0C0);
  static const Color goldTier = Color(0xFFFFD700);
  static const Color diamondTier = Color(0xFFB9F2FF);

  // Additional UI Colors
  static const Color darkPlaceholderBackground = Color(0xFF1E2A25);
  static const Color darkGreenAccent = Color(0xFF2D4A3E);

  static ThemeData get theme {
    return ThemeData(
      primaryColor: darkGreen,
      scaffoldBackgroundColor: backgroundCream,
      colorScheme: const ColorScheme.light(
        primary: darkGreen,
        secondary: goldAccent,
        surface: backgroundCream,
        error: Colors.redAccent,
      ),
      textTheme: TextTheme(
        displayLarge: GoogleFonts.playfairDisplay(
          color: darkGreen,
          fontWeight: FontWeight.bold,
        ),
        displayMedium: GoogleFonts.playfairDisplay(
          color: darkGreen,
          fontWeight: FontWeight.bold,
        ),
        titleLarge: GoogleFonts.playfairDisplay(
          color: darkGreen,
          fontWeight: FontWeight.bold,
        ),
        bodyLarge: GoogleFonts.inter(
          color: darkGreen,
        ),
        bodyMedium: GoogleFonts.inter(
          color: darkGreen,
        ),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: backgroundCream,
        foregroundColor: darkGreen,
        centerTitle: true,
        elevation: 0,
        titleTextStyle: GoogleFonts.playfairDisplay(
          color: darkGreen,
          fontSize: 24,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class AppColors {
  static const Color primary = ThemeManager.darkGreen;
  static const Color secondary = ThemeManager.goldAccent;
  static const Color background = ThemeManager.backgroundCream;

  static const Color darkGreen = ThemeManager.darkGreen;
  static const Color goldAccent = ThemeManager.goldAccent;
  static const Color backgroundCream = ThemeManager.backgroundCream;
  static const Color mintGreen = ThemeManager.mintGreen;
  static const Color lightYellow = ThemeManager.lightYellow;
  static const Color darkGreenAccent = ThemeManager.darkGreenAccent;
  static const Color darkPlaceholderBackground = ThemeManager.darkPlaceholderBackground;

  // Tier Colors
  static const Color bronze = ThemeManager.bronzeTier;
  static const Color silver = ThemeManager.silverTier;
  static const Color gold = ThemeManager.goldTier;
  static const Color diamond = ThemeManager.diamondTier;
}

class AppTextTheme {
  static TextTheme of(BuildContext context) => Theme.of(context).textTheme;

  static TextStyle? title(BuildContext context) => of(context).titleLarge?.copyWith(
        color: AppColors.darkGreen,
        fontWeight: FontWeight.bold,
      );

  static TextStyle? body(BuildContext context) => of(context).bodyLarge?.copyWith(
        color: AppColors.darkGreen,
      );

  static TextStyle? caption(BuildContext context) => of(context).bodySmall?.copyWith(
        color: AppColors.darkGreen.withValues(alpha: 0.6),
      );
}
